from django.db import models


# Create your models here.
class LoginTable(models.Model):
    login_id = models.AutoField(primary_key=True)
    login_username = models.CharField(max_length=255, null=False)
    login_password = models.CharField(max_length=255, null=False)
    login_role = models.CharField(max_length=10, null=False)
    login_status = models.CharField(max_length=10, null=False)
    login_secretkey = models.CharField(max_length=255, null=False)

    def __str__(self):
        return "%s %s %s %s %s %s" % (
            self.login_id, self.login_username, self.login_password, self.login_role, self.login_status,
            self.login_secretkey)

    class Meta:
        db_table = "logintable"
