from django.contrib import admin
from validator.models import LoginTable

# Register your models here.
admin.site.register(LoginTable)
