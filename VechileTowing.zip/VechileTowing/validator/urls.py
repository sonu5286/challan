from validator import views
from django.urls import path

urlpatterns = [
    path('', views.login, name='login'),
    path('validateuser', views.validateuser, name='validateuser'),
    path('logout', views.logout, name='logout')
]
