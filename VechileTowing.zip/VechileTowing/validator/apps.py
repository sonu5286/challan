from django.apps import AppConfig


class ValidatorConfig(AppConfig):
    name = 'validator'
