from django.shortcuts import render, redirect, HttpResponse
from usercontroller.models import UserTable
from validator.models import LoginTable
from inspectorcontroller.models import InspectorTable
from django.contrib import messages


# Create your views here.
def login(request):
    # try:
        print("hallo")
        return render(request, 'login.html')
    # except Exception as ex:
    #     print('login error occured>>>>>>>>>>', ex)


def validateuser(request):
    try:
        useremail = request.POST.get('email')
        password = request.POST.get('password')
        check_user = LoginTable.objects.filter(login_username=useremail, login_password=password)
        print(check_user)
        if len(check_user) == 1 and check_user[0].login_role == 'admin':
            request.session['role'] = 'admin'
            return render(request, 'admin/index.html')
        elif len(check_user) == 1 and check_user[0].login_role == 'user':
            user = UserTable.objects.get(user_email=useremail)
            request.session['role'] = 'user'
            request.session['user'] = user.user_id
            return render(request, 'user/index.html')
        elif len(check_user) == 1 and check_user[0].login_role == 'inspector':
            inspector = InspectorTable.objects.get(inspector_email=useremail)
            request.session['role'] = 'inspector'
            request.session['user'] = inspector.inspector_id
            return render(request, 'inspector/index.html')
        else:
            message = 'Entered email or password may be wrong!!!'
            messages.add_message(request, messages.ERROR, message)
            return redirect(login)
    except Exception as ex:
        print('validateuser error occured>>>>>>>>>>', ex)


def logout(request):
    # try:
    #     if request.session['login_secretekey_admin'] == 'adminloggedin':
    #         request.session['login_secretekey_admin'] = 'adminloggedout'
    #         return render(request, 'login.html')
    #     elif request.session['login_secretekey_user'] == 'userloggedin':
    #         request.session['login_secretekey_user'] = 'userloggedout'
    #         return render(request, 'login.html')
    #     else:
    return redirect(login)
    # except Exception as ex:
    #     print('admin_logout error occured>>>>>>>>>>', ex)
