from django.apps import AppConfig


class InspectorcontrollerConfig(AppConfig):
    name = 'inspectorcontroller'
