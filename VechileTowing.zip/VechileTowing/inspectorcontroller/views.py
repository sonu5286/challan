from django.shortcuts import render, redirect
from inspectorcontroller.models import InspectorTable, ChallanTable
from validator.views import login
from datetime import datetime


# Create your views here.


def inspectoredit(request):
    try:
        if request.session['role'] == 'inspector':
            inspector = InspectorTable.objects.get(inspector_id=request.session['user'])
            print(inspector)
            return render(request, 'inspector/editinspector.html', {'inspectordata': inspector})
    except Exception as ex:
        print('inspector edit error occured>>>>>>>>>>', ex)


def inspectorupdate(request):
    try:
        if request.session['role'] == 'inspector':
            inspector = InspectorTable.objects.get(inspector_id=request.POST.get('inspectorid'))
            inspector.inspector_fullname = request.POST.get('inspectorfullname')
            inspector.inspector_service_id = request.POST.get('inspectorserviceid')
            inspector.inspector_email = request.POST.get('inspectoremail')
            inspector.inspector_password = request.POST.get('inspectorpassword')
            inspector.inspector_contact = request.POST.get('inspectorcontact')
            inspector.inspector_police_station = request.POST.get('inspectorpolicestation')
            inspector.save()
            return render(request, 'inspector/index.html')
    except Exception as ex:
        print('inspector updateinspector error occured>>>>>>>>>>', ex)


def inspectoraddchallan(request):
    try:
        if request.session['role'] == 'inspector':
            return render(request, 'inspector/finechallan.html')
        else:
            return redirect(login)
    except Exception as ex:
        print('inspector addchallan error occured>>>>>>>>>>', ex)


def inspectorfilechallan(request):
    try:
        if request.session['role'] == 'inspector':
            challan = ChallanTable()
            challan.challan_place = request.POST.get('challanplace')
            challan.challan_fine_amount = request.POST.get('challanFineamount')
            challan.challan_vechile_number = request.POST.get('challanvechilenumber')
            challan.challan_status = 'pending'
            challan.challan_by_inspector = request.session['user']
            challan.challan_date = datetime.now()
            challan.save()
            return redirect(inspectorviewchallan)
        else:
            return redirect(login)
    except Exception as ex:
        print('inspector insertchallan error occured>>>>>>>>>>', ex)


def inspectorviewchallan(request):
    try:
        if request.session['role'] == 'inspector':
            challan = ChallanTable.objects.get(challan_by_inspector=request.session['user'])
            data = []
            for i in range(0, len(challan)):
                data.append(challan[i])
            return render(request, 'inspector/challanhistory.html', {'challandata': data})
        else:
            return redirect(login)
    except Exception as ex:
        print('inspector viewchallan error occured>>>>>>>>>>', ex)
