from django.urls import path
from inspectorcontroller import views

urlpatterns = [
    path('inspector/addchallan', views.inspectoraddchallan, name='addcallan'),
    path('inspector/filechallan', views.inspectorfilechallan, 'filechallan'),
    path('inspector/viewchallan', views.inspectorviewchallan, 'viewchallan'),
    path('inspector/editinspector', views.inspectoredit, name='editinspector'),
    path('inspector/updatinspector', views.inspectorupdate, name='updateinspector'),
]
