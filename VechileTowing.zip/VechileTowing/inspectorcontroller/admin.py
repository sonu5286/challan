from django.contrib import admin
from inspectorcontroller.models import ChallanTable, InspectorTable

# Register your models here.
admin.site.register(ChallanTable)
admin.site.register(InspectorTable)
