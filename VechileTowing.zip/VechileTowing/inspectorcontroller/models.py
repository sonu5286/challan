from django.db import models
from usercontroller.models import VechileTable


# Create your models here.
class InspectorTable(models.Model):
    inspector_id = models.AutoField(primary_key=True)
    inspector_fullname = models.CharField(max_length=255, null=False)
    inspector_email = models.CharField(max_length=255, null=False)
    inspector_password = models.CharField(max_length=255, null=False)
    inspector_service_id = models.CharField(max_length=255, null=False)
    inspector_contact = models.CharField(max_length=12, null=False)
    inspector_police_station = models.CharField(max_length=255, null=False)

    def __str__(self):
        return '%s %s %s %s %s %s %s' % (
            self.inspector_id, self.inspector_fullname, self.inspector_service_id, self.inspector_password,
            self.inspector_contact, self.inspector_police_station, self.inspector_email)

    class Meta:
        db_table = 'inspectortable'


class ChallanTable(models.Model):
    challan_id = models.AutoField(primary_key=True)
    challan_place = models.CharField(max_length=255, null=False)
    challan_date = models.DateTimeField(max_length=255, null=False)
    challan_fine_amount = models.CharField(max_length=255, null=False)
    challan_status = models.CharField(max_length=10, null=False)
    challan_vechile_number = models.ForeignKey(VechileTable, on_delete=models.CASCADE)
    challan_by_inspector = models.ForeignKey(InspectorTable, on_delete=models.CASCADE)

    def __str__(self):
        return '%s %s %s %s %s %s' % (
            self.challan_id, self.challan_vechile_number, self.challan_date, self.challan_place, self.challan_fine_amount,
            self.challan_status)

    class Meta:
        db_table = 'challantable'
