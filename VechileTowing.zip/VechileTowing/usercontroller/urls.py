from django.urls import path
from usercontroller import views

urlpatterns = [
    path('user/register', views.userregister, name='registeruser'),
    path('user/insert', views.insertuser, name='insertuser'),

    path('user/addvechile', views.useraddvechile, name='addvechile'),
    path('user/insertvechile', views.userinsertvechile, name='insertvechile'),
    path('user/viewvechile', views.userviewvechile, name='viewvechile'),
    path('user/deletevechile/<int:vechile_delete_id>', views.userdeletevechile, name='deletevechile'),
    path('user/editvechile/<int:vechile_edit_id>', views.usereditvechile, name='editvechile'),
    path('user/updatevechile', views.userupdatevechile, name='updatevechile'),

    path('user/edituser', views.useredit, name='edituser'),
    path('user/updateuser', views.userupdate, name='updateuser'),
]
