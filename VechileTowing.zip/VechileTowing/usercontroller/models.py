from django.db import models


# Create your models here.
class UserTable(models.Model):
    user_id = models.AutoField(primary_key=True)
    user_fullname = models.CharField(max_length=255, null=False)
    user_email = models.CharField(max_length=255, null=False)
    user_password = models.CharField(max_length=255, null=False)
    user_contact = models.CharField(max_length=12, null=False)
    user_address = models.CharField(max_length=255, null=False)

    def __str__(self):
        return '%s %s %s %s %s %s' % (
            self.user_id, self.user_fullname, self.user_email, self.user_password, self.user_contact, self.user_address)

    class Meta:
        db_table = 'usertable'


class VechileTable(models.Model):
    vechile_id = models.AutoField(primary_key=True)
    vechile_registration_number = models.CharField(max_length=255, null=False)
    vechile_registration_year = models.CharField(max_length=255, null=False)
    vechile_owner = models.ForeignKey(UserTable, on_delete=models.CASCADE)

    def __str__(self):
        return '%s %s %s %s' % (
            self.vechile_id, self.vechile_registration_number, self.vechile_registration_year, self.vechile_owner_id)

    class Meta:
        db_table = 'vechiletable'
