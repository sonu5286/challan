from django.shortcuts import render, redirect
from validator.views import login
from usercontroller.models import UserTable, VechileTable
from validator.models import LoginTable
from django.contrib import messages
import secrets


# Create your views here.
def userregister(request):
    try:
        return render(request, 'register.html')
    except Exception as ex:
        print('user register error occured>>>>>>>>>>', ex)


def insertuser(request):
    try:
        user = UserTable()
        login = LoginTable()

        email_exist = request.POST.get('email')
        record = LoginTable.objects.filter(login_username=email_exist)
        if len(record) == 0:
            login.login_username = request.POST.get('email')
            login.login_password = request.POST.get('password')
            login.login_role = 'user'
            login.login_status = 'active'
            login.login_secretkey = secrets.token_hex(32)

            user.user_fullname = request.POST.get('fullname')
            user.user_email = request.POST.get('email')
            user.user_password = request.POST.get('password')
            user.user_contact = request.POST.get('contact')
            user.user_address = request.POST.get('address')

            user.save()
            login.save()

            message = 'Register Successfully!!!'
            messages.add_message(request, messages.SUCCESS, message)
            return redirect('/')
        else:
            message = 'Email is already registerd!!!'
            messages.add_message(request, messages.ERROR, message)
            return redirect('/')
    except Exception as ex:
        print('insert user exception error occured>>>>>>>>>>', ex)


def useraddvechile(request):
    try:
        if request.session['role'] == 'user':
            return render(request, 'user/addvechile.html')
        else:
            return redirect(login)
    except Exception as ex:
        print('user addvechile error occured>>>>>>>>>>', ex)


def userinsertvechile(request):
    try:
        if request.session['role'] == 'user':
            vechile = VechileTable()
            vechile.vechile_registration_number = request.POST.get('vechile_registration_number')
            vechile.vechile_owner_id = request.session['user']
            vechile.vechile_registration_year = request.POST.get('vechile_registration_year')
            vechile.save()
            return redirect(userviewvechile)
        else:
            return redirect(login)
    except Exception as ex:
        print('user insertvechile error occured>>>>>>>>>>', ex)


def userviewvechile(request):
    try:
        if request.session['role'] == 'user':
            vechile = VechileTable.objects.filter(vechile_owner_id=request.session['user'])
            data = []
            for i in range(0, len(vechile)):
                data.append(vechile[i])
            return render(request, 'user/viewvechile.html', {'vechiledata': data})
        else:
            return redirect(login)
    except Exception as ex:
        print('user viewvechile error occured>>>>>>>>>>', ex)


def userdeletevechile(request, vechile_delete_id):
    try:
        if request.session['role'] == 'user':
            VechileTable.objects.get(vechile_id=vechile_delete_id).delete()
            return redirect(userviewvechile)
        else:
            return redirect(login)
    except Exception as ex:
        print('user deletevechile error occured>>>>>>>>>>', ex)


def usereditvechile(request, vechile_edit_id):
    try:
        if request.session['role'] == 'user':
            vechile = VechileTable.objects.get(vechile_id=vechile_edit_id)
            return render(request, 'user/editvechile.html', {'vechiledata': vechile})
    except Exception as ex:
        print('user vechile error occured>>>>>>>>>>', ex)


def userupdatevechile(request):
    try:
        if request.session['role'] == 'user':
            vechile = VechileTable.objects.get(vechile_id=request.POST.get('vechileid'))
            vechile.vechile_owner_id = request.session['user']
            vechile.vechile_registration_number = request.POST.get('vechile_registration_number')
            vechile.vechile_registration_year = request.POST.get('vechile_registration_year')
            vechile.save()
            return redirect(userviewvechile)
    except Exception as ex:
        print('user updatevechile error occured>>>>>>>>>>', ex)


def useredit(request):
    try:
        if request.session['role'] == 'user':
            user = UserTable.objects.get(user_id=request.session['user'])
            print(user)
            return render(request, 'user/editinspector.html', {'userdata': user})
    except Exception as ex:
        print('user edit error occured>>>>>>>>>>', ex)


def userupdate(request):
    try:
        if request.session['role'] == 'user':
            user = UserTable.objects.get(user_id=request.POST.get('userid'))
            user.user_fullname = request.POST.get('fullname')
            user.user_email = request.POST.get('email')
            user.user_password = request.POST.get('password')
            user.user_contact = request.POST.get('contact')
            user.user_address = request.POST.get('address')
            user.save()
            return render(request, 'user/index.html')
    except Exception as ex:
        print('user updateuser error occured>>>>>>>>>>', ex)
