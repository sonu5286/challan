from django.contrib import admin
from usercontroller.models import UserTable, VechileTable

# Register your models here.
admin.site.register(UserTable)
admin.site.register(VechileTable)
