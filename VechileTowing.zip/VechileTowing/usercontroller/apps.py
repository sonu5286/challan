from django.apps import AppConfig


class UsercontrollerConfig(AppConfig):
    name = 'usercontroller'
