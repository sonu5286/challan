from django.contrib import admin
from admincontroller.models import StateTable, CityTable, AreaTable

# Register your models here.
admin.site.register(StateTable)
admin.site.register(CityTable)
admin.site.register(AreaTable)
