from django.apps import AppConfig


class AdmincontrollerConfig(AppConfig):
    name = 'admincontroller'
