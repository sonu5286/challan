from admincontroller import views
from django.urls import path

urlpatterns = [
    path('admin/addstate', views.adminaddstate, name='addstate'),
    path('admin/insertstate', views.admininsertstate, name='insertstate'),
    path('admin/viewstate', views.adminviewstate, name='viewstate'),
    path('admin/deletestate/<int:state_delete_id>', views.admindeletestate, name='deletestate'),
    path('admin/editstate/<int:state_edit_id>', views.admineditstate, name='editstate'),
    path('admin/updatestate', views.adminupdatestate, name='updatestate'),

    path('admin/addcity', views.adminaddcity, name='addcity'),
    path('admin/insertcity', views.admininsertcity, name='insertcity'),
    path('admin/viewcity', views.adminviewcity, name='viewcity'),
    path('admin/deletecity/<int:city_delete_id>', views.admindeletecity, name='deletecity'),
    path('admin/editcity/<int:city_edit_id>', views.admineditcity, name='editcity'),
    path('admin/updatecity', views.adminupdatecity, name='updatecity'),

    path('admin/addarea', views.adminaddarea, name='addarea'),
    path('admin/insertarea', views.admininsertarea, name='insertarea'),
    path('admin/viewarea', views.adminviewarea, name='viewarea'),
    path('admin/deletearea/<int:area_delete_id>', views.admindeletearea, name='deletearea'),
    path('admin/editarea/<int:area_edit_id>', views.admineditarea, name='editarea'),
    path('admin/updatearea', views.adminupdatearea, name='updatearea'),

    path('admin/userlist', views.adminuserlist, name='userslist'),
    path('ajaxfunction/', views.ajaxfunction, name='ajaxfunction'),
]
