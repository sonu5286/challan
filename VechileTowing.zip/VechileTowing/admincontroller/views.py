from admincontroller.models import StateTable, CityTable, AreaTable
from django.shortcuts import render, redirect, HttpResponse
from django.forms import model_to_dict
from usercontroller.models import UserTable
from validator.views import login
import json


# Create your views here.
def adminaddstate(request):
    try:
        if request.session['role'] == 'admin':
            return render(request, 'admin/addstate.html')
        else:
            return redirect(login)
    except Exception as ex:
        print('admin addstate error occured>>>>>>>>>>', ex)


def admininsertstate(request):
    try:
        if request.session['role'] == 'admin':
            state = StateTable()
            state.state_name = request.POST.get('statename')
            state.state_description = request.POST.get('statedescription')
            state.save()
            return redirect(adminviewstate)
        else:
            return redirect(login)
    except Exception as ex:
        print('admin insertstate error occured>>>>>>>>>>', ex)


def adminviewstate(request):
    try:
        if request.session['role'] == 'admin':
            states = StateTable.objects.all()
            data = []
            for i in range(0, len(states)):
                data.append(states[i])
            return render(request, 'admin/viewstate.html', {'statedata': data})
        else:
            return redirect(login)
    except Exception as ex:
        print('admin viewstate error occured>>>>>>>>>>', ex)


def admindeletestate(request, state_delete_id):
    try:
        if request.session['role'] == 'admin':
            StateTable.objects.get(state_id=state_delete_id).delete()
            return redirect(adminviewstate)
        else:
            return redirect(login)
    except Exception as ex:
        print('admin deletestate error occured>>>>>>>>>>', ex)


def admineditstate(request, state_edit_id):
    try:
        if request.session['role'] == 'admin':
            state = StateTable.objects.get(state_id=state_edit_id)
            return render(request, 'admin/editstate.html', {'statedata': state})
    except Exception as ex:
        print('admin editstate error occured>>>>>>>>>>', ex)


def adminupdatestate(request):
    try:
        if request.session['role'] == 'admin':
            state = StateTable()
            state.state_id = request.POST.get('stateid')
            state.state_name = request.POST.get('statename')
            state.state_description = request.POST.get('statedescription')
            state.save()
            return redirect(adminviewstate)
    except Exception as ex:
        print('admin updatestate error occured>>>>>>>>>>', ex)


def adminaddcity(request):
    try:
        if request.session['role'] == 'admin':
            states = StateTable.objects.all()
            return render(request, 'admin/addcity.html', {'statedata': states})
        else:
            return redirect(login)
    except Exception as ex:
        print('admin addcity error occured>>>>>>>>>>', ex)


def admininsertcity(request):
    try:
        if request.session['role'] == 'admin':
            city = CityTable()
            city.city_state_id = request.POST.get('stateid')
            city.city_name = request.POST.get('cityname')
            city.city_description = request.POST.get('citydescription')
            city.save()
            return redirect(adminviewcity)
        else:
            return redirect(login)
    except Exception as ex:
        print('admin insertcity error occured>>>>>>>>>>', ex)


def adminviewcity(request):
    try:
        if request.session['role'] == 'admin':
            citys = CityTable.objects.all()
            data = []
            for i in range(0, len(citys)):
                data.append(citys[i])
            return render(request, 'admin/viewcity.html', {'citydata': data})
        else:
            return redirect(login)
    except Exception as ex:
        print('admin viewcity error occured>>>>>>>>>>', ex)


def admindeletecity(request, city_delete_id):
    try:
        if request.session['role'] == 'admin':
            CityTable.objects.get(city_id=city_delete_id).delete()
            return redirect(adminviewcity)
        else:
            return redirect(login)
    except Exception as ex:
        print('admin deletecity error occured>>>>>>>>>>', ex)


def admineditcity(request, city_edit_id):
    try:
        if request.session['role'] == 'admin':
            states = StateTable.objects.all()
            city = CityTable.objects.get(city_id=city_edit_id)
            return render(request, 'admin/editcity.html', {'statedata': states, 'citydata': city})
    except Exception as ex:
        print('admin editcity error occured>>>>>>>>>>', ex)


def adminupdatecity(request):
    try:
        if request.session['role'] == 'admin':
            city = CityTable()
            city.city_id = request.POST.get('cityid')
            city.city_name = request.POST.get('cityname')
            city.city_description = request.POST.get('citydescription')
            city.city_state_id = request.POST.get('stateid')
            city.save()
            return redirect(adminviewcity)
    except Exception as ex:
        print('admin updatecity error occured>>>>>>>>>>', ex)


def adminaddarea(request):
    try:
        if request.session['role'] == 'admin':
            states = StateTable.objects.all()
            return render(request, 'admin/addarea.html', {'statedata': states})
        else:
            return redirect(login)
    except Exception as ex:
        print('admin addarea error occured>>>>>>>>>>', ex)


def admininsertarea(request):
    try:
        if request.session['role'] == 'admin':
            area = AreaTable()
            area.area_city_id = request.POST.get('cityid')
            area.area_name = request.POST.get('areaname')
            area.area_pincode = request.POST.get('areapincode')
            area.save()
            return redirect(adminviewarea)
        else:
            return redirect(login)
    except Exception as ex:
        print('admin insertarea error occured>>>>>>>>>>', ex)


def adminviewarea(request):
    try:
        if request.session['role'] == 'admin':
            areas = AreaTable.objects.all()
            data = []
            for i in range(0, len(areas)):
                data.append(areas[i])
            return render(request, 'admin/viewarea.html', {'areadata': data})
        else:
            return redirect(login)
    except Exception as ex:
        print('admin viewarea error occured>>>>>>>>>>', ex)


def admindeletearea(request, area_delete_id):
    try:
        if request.session['role'] == 'admin':
            AreaTable.objects.get(area_id=area_delete_id).delete()
            return redirect(adminviewarea)
        else:
            return redirect(login)
    except Exception as ex:
        print('admin deletearea error occured>>>>>>>>>>', ex)


def admineditarea(request, area_edit_id):
    try:
        if request.session['role'] == 'admin':
            states = StateTable.objects.all()
            area = AreaTable.objects.get(area_id=area_edit_id)
            return render(request, 'admin/editarea.html', {'statedata': states, 'areadata': area})
    except Exception as ex:
        print('admin editarea error occured>>>>>>>>>>', ex)


def adminupdatearea(request):
    try:
        if request.session['role'] == 'admin':
            area = AreaTable()
            area.area_id = request.POST.get('areaid')
            area.area_name = request.POST.get('areaname')
            area.area_description = request.POST.get('areadescription')
            area.area_state_id = request.POST.get('stateid')
            area.save()
            return redirect(adminviewarea)
    except Exception as ex:
        print('admin updatearea error occured>>>>>>>>>>', ex)


def adminuserlist(request):
    try:
        if request.session['role'] == 'admin':
            user_list = UserTable.objects.all()
            return render(request, 'admin/user.html', {'userdata': user_list})
        else:
            return redirect(login)
    except Exception as ex:
        print('admin userlist error occured>>>>>>>>>>', ex)


def ajaxfunction(request):
    print("HEllo")
    state_id = request.GET.get('state')
    state = StateTable.objects.get(state_id=state_id)
    citys = CityTable.objects.filter(city_state_id=state)
    json_ls = []
    for i in citys:
        dict = model_to_dict(i)
        json_ls.append(dict)
    dump = json.dumps(json_ls)
    return HttpResponse(dump, content_type='application/json')
