from django.db import models


# Create your models here.
class StateTable(models.Model):
    state_id = models.AutoField(primary_key=True)
    state_name = models.CharField(max_length=255, null=False)
    state_description = models.CharField(max_length=255, null=False)

    def __str__(self):
        return '%s %s %s' % (self.state_id, self.state_name, self.state_description)

    class Meta:
        db_table = 'statetable'


class CityTable(models.Model):
    city_id = models.AutoField(primary_key=True)
    city_name = models.CharField(max_length=255, null=False)
    city_description = models.CharField(max_length=255, null=False)
    city_state = models.ForeignKey(StateTable, on_delete=models.CASCADE)

    def __str__(self):
        return '%s %s %s %s' % (self.city_id, self.city_name, self.city_description, self.city_state_id)

    class Meta:
        db_table = 'citytable'


class AreaTable(models.Model):
    area_id = models.AutoField(primary_key=True)
    area_name = models.CharField(max_length=255, null=False)
    area_pincode = models.CharField(max_length=255, null=False)
    area_city = models.ForeignKey(CityTable, on_delete=models.CASCADE)

    def __str__(self):
        return '%s %s %s %s' % (self.area_id, self.area_name, self.area_pincode, self.area_city_id)

    class Meta:
        db_table = 'areatable'
